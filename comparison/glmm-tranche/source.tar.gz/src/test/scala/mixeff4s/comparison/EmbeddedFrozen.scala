package mixeff4s.comparison

/** Frozen references; see comparison/scripts. */
private[comparison] object EmbeddedFrozen:
  val json: String = Vector(
    """{
  "schema": {
    "name": "mixeff4s.frozen_reference",
    "version": 1
  },
  "source": {
    "mixeff_rs_revision": "d6b81ce8b5974b2f0e42fcf650ad6811e5202a4f",
    "lme4_tool": "lme4 2.0.1",
    "note": "Earlier pins retain their original provenance. Classic LMM workflow pins were generated with live R/lme4; scripts, package versions, frame hashes and full prediction/mode references are under comparison/workflow-tranche. Existing reference values are preserved. There are no p-values."
  },
  "results": [
    {
      "dataset": "sleepstudy",
      "formula": "reaction ~ 1 + days + (1 + days | subj)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 180,
      "objective": 1751.9393444636682,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        251.40510484848454,
        10.467285959596126
      ],
      "coef_names": [
        "(Intercept)",
        "days"
      ],
      "theta": [
        0.9292297167514472,
        0.01816466496782548,
        0.22264601131030412
      ],
      "sigma": 25.591813564885108,
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "sleepstudy",
      "formula": "reaction ~ 1 + days + (1 + days | subj)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 180,
      "objective": 1743.6282719599442,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        251.40510484848528,
        10.467285959595493
      ],
      "coef_names": [
        "(Intercept)",
        "days"
      ],
      "theta": [
        0.9667417690560796,
        0.015169059384716037,
        0.2309099529619309
      ],
      "sigma": 25.591795732317802,
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "sleepstudy",
      "formula": "reaction ~ 1 + days + (1 + days || subj)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 180,
      "objective": 1752.003255140962,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        251.4051048484854,
        10.467285959595674
      ],
      "coef_names": [
        "(Intercept)",
        "days"
      ],
      "theta": [
        0.9458043022417869,
        0.22692740996014607
      ],
      "sigma": 25.55613836753517,
      "is_singular": false,
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "penicillin",
      "formula": "diameter ~ 1 + (1 | plate) + (1 | sample)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 144,
      "objective": 332.1883486700085,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        22.97222222222222
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.5375939045981573,
        3.219792193110907
      ],
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.01
      }
    },
    {
      "dataset": "penicillin",
      "formula": "diameter ~ 1 + (1 | plate) + (1 | sample)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 144,
      "objective": 330.86058899126897,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        22.97222222222248
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.5396773350745998,
        3.51241122181154
      ],
      "sigma": 0.549923173720829,
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.01,
        "sigma": 0.001
      }
    },
    {
      "dataset": "pastes",
      "formula": "strength ~ 1 + (1 | batch / cask)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 60,
      "objective": 247.9944658624955,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        60.0533333333333
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        3.5269029347766856,
        1.3299137410046242
      ],
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.09
      }
    },
    {
      "dataset": "contraception",
      "formula": "use_num ~ 1 + age + age2 + urban + livch + (1 | urban_dist)",
      "family": "Bernoulli",
      "link": "Logit",
      "estimator": "fast_pirls",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 1934,
      "objective": 2361.657202855648,
      "objective_definition": "profiled_fast_pirls_deviance",
      "objective_comparable": true,
      "theta": [
        0.5720746212924732
      ],
      "sigma": 1.0,
      "tolerances": {
        "objective": 1.0,
        "theta": 0.01
      }
    },
    {
      "dataset": "oxide",
      "formula": "Thickness ~ 1 + (1 | Lot) + (1 | Lot:Wafer)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 72,
      "objective": 454.02206930988217,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        2000.152777777835
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.6892198720377958,
        3.2149146331969516
      ],
      "sigma": 3.5453258700425447,
      "is_singular": false,
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "oxide",
      "formula": "Thickness ~ 1 + (1 | Lot/Wafer)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixedmodels.jl",
      "status": "ok",
      "n_obs": 72,
      "objective": 454.02206930988217,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        2000.152777777835
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.6892198720377958,
        3.2149146331969516
      ],
      "sigma": 3.5453258700425447,
      "is_singular": false,
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "cake",
      "formula": "angle ~ 1 + recipe * temperature + (1 | recipe:replicate)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 270,
      "objective": 1633.246181533657,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        29.133333333332015,
        -2.2666666666652615,
        -1.199999999998692,
        2.400000000000378,
        1.6666666666670484,
        4.40000000000038,
        9.533333333333706,
        5.933333333333708,
        0.1333333333329079,
        3.199999999999569,
        0.8666666666662394,
        -1.9333333333337546,
        2.4666666666662413,
        -1.4000000000004051,
        2.133333333332924,
        -1.4666666666670733,
        -3.066666666667067,
        1.8666666666662612
      ],
      "coef_names": [
        "(Intercept)",
        "recipe: B",
        "recipe: C",
        "temperature: 185",
        "temperature: 195",
        "temperature: 205",
        "temperature: 215",
        "temperature: 225",
        "recipe: B:temperature: 185",
        "recipe: B:temperature: 195",
        "recipe: B:temperature: 205",
        "recipe: B:temperature: 215",
        "recipe: B:temperature: 225",
        "recipe: C:temperature: 185",
        "recipe: C:temperature: 195",
        "recipe: C:temperature: 205",
        "recipe: C:temperature: 215",
        "recipe: C:temperature: 225"
      ],
      "theta": [
        1.4296373923248473
      ],
      "sigma": 4.524455494621483,
      "is_singular": false
    },
    {
      "dataset": "dyestuff",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 30,
      "objective": 319.65427684225597,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        1527.4999999999998
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0.8483243229023545
      ],
      "sigma": 49.5100957160886,
      "is_singular": false
    },
    {
      "dataset": "dyestuff",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 30,
      "objective": 327.327059881646,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        1527.5000000000007
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0.7525732146822598
      ],
      "sigma": 49.51017269106905,
      "is_singular": false
    },
    {
      "dataset": "dyestuff2",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 30,
      "objective": 162.87303665382575,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        5.665600000000001
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0.0
      ],
      "sigma": 3.6532313513746506,
      "is_singular": true
    },
    {
      "dataset": "dyestuff2",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 30,
      "objective": 161.82827781228843,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        5.665600000000001
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0.0
      ],
      "sigma": 3.7156842744757252,
      "is_singular": true
    },
    {
      "dataset": "ergostool",
      "formula": "effort ~ 1 + Type + (1 | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 36,
      "objective": 121.13078870237001,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        8.555555555555578,
        3.888888888888884,
        2.2222222222222183,
        0.6666666666666627
      ],
      "coef_names": [
        "(Intercept)",
        "Type: T2",
        "Type: T3",
        "Type: T4"
      ],
      "theta": [
        1.21101540341102
      ],
      "sigma": 1.1002930421604715,
      "is_singular": false
    },
    {
      "dataset": "machines",
      "formula": "score ~ 1 + Machine + (1 | Worker) + (1 | Worker:Machine)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 54,
      "objective": 215.6875""",
    """6800825344,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        52.35555555555739,
        7.966666666664733,
        13.916666666664797
      ],
      "coef_names": [
        "(Intercept)",
        "Machine: B",
        "Machine: C"
      ],
      "theta": [
        3.8785676635568356,
        4.972094674999198
      ],
      "sigma": 0.9615765573579709,
      "is_singular": false
    },
    {
      "dataset": "machines",
      "formula": "score ~ 1 + Machine + (1 + Machine | Worker)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 54,
      "objective": 208.3112224111597,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        52.35555555554916,
        7.966666666662151,
        13.916666666668874
      ],
      "coef_names": [
        "(Intercept)",
        "Machine: B",
        "Machine: C"
      ],
      "theta": [
        4.241514016212989,
        2.956383725400436,
        -1.4020477707225698,
        5.34904602313131,
        2.076814579400609,
        2.9091656629309077
      ],
      "sigma": 0.9615514521778123,
      "is_singular": false
    },
    {
      "dataset": "oats",
      "formula": "yield ~ 1 + Variety * nitro + (1 | Block) + (1 | Block:Variety)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 72,
      "objective": 563.2371973325536,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        81.90000000000032,
        8.51666666666659,
        -8.600000000000092,
        75.33333333333388,
        -10.750000000000425,
        5.74999999999955
      ],
      "coef_names": [
        "(Intercept)",
        "Variety: Marvellous",
        "Variety: Victory",
        "nitro",
        "Variety: Marvellous:nitro",
        "Variety: Victory:nitro"
      ],
      "theta": [
        0.8005374714588508,
        1.1273752941114275
      ],
      "sigma": 12.990380942169908,
      "is_singular": false
    },
    {
      "dataset": "orthodont",
      "formula": "distance ~ 1 + age * Sex + (1 + age | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 108,
      "objective": 432.58166700445105,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        16.34062499999952,
        0.7843750000000627,
        1.0321022727275506,
        -0.3048295454545986
      ],
      "coef_names": [
        "(Intercept)",
        "age",
        "Sex: Female",
        "age:Sex: Female"
      ],
      "theta": [
        1.8341032568529057,
        -0.09169127471927235,
        0.10244261307250545
      ],
      "sigma": 1.3102124935353376,
      "is_singular": false
    },
    {
      "dataset": "oxide",
      "formula": "Thickness ~ 1 + (1 | Lot) + (1 | Lot:Wafer)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 72,
      "objective": 454.02206930524136,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        2000.1527777779258
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.6892280284480479,
        3.2149721524638952
      ],
      "sigma": 3.545316604036649,
      "is_singular": false
    },
    {
      "dataset": "oxide",
      "formula": "Thickness ~ 1 + (1 | Lot/Wafer)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 72,
      "objective": 454.02206930524136,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        2000.1527777779258
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.6892280284480479,
        3.2149721524638952
      ],
      "sigma": 3.545316604036649,
      "is_singular": false
    },
    {
      "dataset": "pastes",
      "formula": "strength ~ 1 + (1 | sample) + (1 | batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 60,
      "objective": 246.99074585342348,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        60.053333333334166
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        3.5269055170508676,
        1.5634659013792063
      ],
      "sigma": 0.8234070274632455,
      "is_singular": false
    },
    {
      "dataset": "penicillin",
      "formula": "diameter ~ 1 + (1 | plate) + (1 | sample)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 144,
      "objective": 330.86058899126897,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        22.97222222222248
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.5396773350745998,
        3.51241122181154
      ],
      "sigma": 0.549923173720829,
      "is_singular": false
    },
    {
      "dataset": "rail",
      "formula": "travel ~ 1 + (1 | Rail)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 18,
      "objective": 122.17700080985884,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        66.49999999999962
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        6.169234589854954
      ],
      "sigma": 4.020795157094695,
      "is_singular": false
    },
    {
      "dataset": "sleepstudy",
      "formula": "Reaction ~ 1 + Days + (1 + Days | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 180,
      "objective": 1743.6282719599442,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        251.40510484848528,
        10.467285959595493
      ],
      "coef_names": [
        "(Intercept)",
        "Days"
      ],
      "theta": [
        0.9667417690560796,
        0.015169059384716037,
        0.2309099529619309
      ],
      "sigma": 25.591795732317802,
      "is_singular": false
    },
    {
      "dataset": "sleepstudy",
      "formula": "Reaction ~ 1 + Days + (1 + Days | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 180,
      "objective": 1751.939344474405,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        251.40510484848537,
        10.4672859595958
      ],
      "coef_names": [
        "(Intercept)",
        "Days"
      ],
      "theta": [
        0.9292145007480422,
        0.018171743703656894,
        0.222646742690827
      ],
      "sigma": 25.591813564885108,
      "is_singular": false
    },
    {
      "dataset": "station_season_duration",
      "formula": "effect ~ 1 + duration + (1 + duration | sites) + (1 + duration | season)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 54,
      "objective": 999.7488676069531,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        4183.895814814807,
        3265.640851851847
      ],
      "coef_names": [
        "(Intercept)",
        "duration: 7d"
      ],
      "theta": [
        1.0323422452749194,
        0.4781038654677432,
        0.0,
        0.24512729116404197,
        0.22592017022921554,
        5.9308918041924695e-05
      ],
      "sigma": 2248.630143493233,
      "is_singular": true
    },
    {
      "dataset": "station_season_duration",
      "formula": "effect ~ 1 + duration * season * sites",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixeff-rs",
      "status": "error",
      "n_obs": 54,
      "objective_comparable": true
    },
    {
      "dataset": "station_season_duration",
      "formula": "effect ~ 1 + duration + (1 | sites) + (1 | season)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "mixeff-rs",
      "status": "ok",
      "n_obs": 54,
      "objective": 1003.104980178335,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        4183.89581481484,
        3265.6408518518515
      ],
      "coef_names": [
        "(Intercept)",
        "duration: 7d"
      ],
      "theta": [
        1.2209745251437865,
        0.3298797961292596
      ],
      "sigma": 2335.4417695372567,
      "is_singular": false
    },
    {
      "dataset": "cake",
      "formula": "angle ~ 1 + recipe * temperature + (1 | recipe:replicate)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 270,
      "objective": 1633.2462,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        29.1333,
        -2.2667,
        -1.2,
        2.4,
        1.6667,
        4.4,
        9.5333,
        5.9333,
        0.1333,
        -1.4,
        3.2,
        2.1333,
        0.8667,
        -1.4667,
        -1.9333,
        -3.0667,
        2.4667,
        1.8667
      ],
      "coef_names": [
        "(Intercept)",
        "recipeB",
        "recipeC",
        "temperature185",
        "temperature195",
        "temperature205",
        "temperature215",
        "temperature225",
        "recipeB:temperature185",
        "recipeC:temperature185",
        "recipeB:temperature195",
        "recipeC:temperature195",
        "recipeB:temperature205",
        "recipeC:temperature205",
        "recipeB:temperature215",
        "recipeC:temperature215",
        "recipeB:temperature225",
        "recipeC:temperature225"
      ],
      "theta": [
        1.4296
      ],
      "sigma": 4.5245,
      "is_singular": false
    },
    {
      "dataset": "dyestuff",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 30,
      "objective": 319.6543,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        1527.5
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0.8483
      ],
      "sigma": 49.5101,
      "is_singular": false
    },
    {
      "dataset": "dyestuff",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 30,
      "objective": 327.3271,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        1527.5
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0.7526
      ],
      "sigma": 49.5101,
      "is_singular": false
    },
    {
      "dataset": "dyestuff2",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 30,
      "objective": 162.873,
      "objective_defi""",
    """nition": "deviance",
      "objective_comparable": true,
      "beta": [
        5.6656
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0
      ],
      "sigma": 3.6532,
      "is_singular": true
    },
    {
      "dataset": "dyestuff2",
      "formula": "Yield ~ 1 + (1 | Batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 30,
      "objective": 161.8283,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        5.6656
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        0
      ],
      "sigma": 3.7157,
      "is_singular": true
    },
    {
      "dataset": "ergostool",
      "formula": "effort ~ 1 + Type + (1 | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 36,
      "objective": 121.1308,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        8.5556,
        3.8889,
        2.2222,
        0.6667
      ],
      "coef_names": [
        "(Intercept)",
        "TypeT2",
        "TypeT3",
        "TypeT4"
      ],
      "theta": [
        1.211
      ],
      "sigma": 1.1003,
      "is_singular": false
    },
    {
      "dataset": "machines",
      "formula": "score ~ 1 + Machine + (1 | Worker) + (1 | Worker:Machine)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 54,
      "objective": 215.6876,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        52.3556,
        7.9667,
        13.9167
      ],
      "coef_names": [
        "(Intercept)",
        "MachineB",
        "MachineC"
      ],
      "theta": [
        3.8786,
        4.9721
      ],
      "sigma": 0.9616,
      "is_singular": false
    },
    {
      "dataset": "machines",
      "formula": "score ~ 1 + Machine + (1 + Machine | Worker)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 54,
      "objective": 208.3112,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        52.3556,
        7.9667,
        13.9167
      ],
      "coef_names": [
        "(Intercept)",
        "MachineB",
        "MachineC"
      ],
      "theta": [
        4.2425,
        2.9588,
        -1.4008,
        5.3497,
        2.076,
        2.9075
      ],
      "sigma": 0.9616,
      "is_singular": false
    },
    {
      "dataset": "oats",
      "formula": "yield ~ 1 + Variety * nitro + (1 | Block) + (1 | Block:Variety)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 72,
      "objective": 563.2372,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        81.9,
        8.5167,
        -8.6,
        75.3333,
        -10.75,
        5.75
      ],
      "coef_names": [
        "(Intercept)",
        "VarietyMarvellous",
        "VarietyVictory",
        "nitro",
        "VarietyMarvellous:nitro",
        "VarietyVictory:nitro"
      ],
      "theta": [
        0.8005,
        1.1274
      ],
      "sigma": 12.9904,
      "is_singular": false
    },
    {
      "dataset": "orthodont",
      "formula": "distance ~ 1 + age * Sex + (1 + age | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 108,
      "objective": 432.5817,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        16.3406,
        0.7844,
        1.0321,
        -0.3048
      ],
      "coef_names": [
        "(Intercept)",
        "age",
        "SexFemale",
        "age:SexFemale"
      ],
      "theta": [
        1.8341,
        -0.0917,
        0.1025
      ],
      "sigma": 1.3102,
      "is_singular": false
    },
    {
      "dataset": "oxide",
      "formula": "Thickness ~ 1 + (1 | Lot) + (1 | Lot:Wafer)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 72,
      "objective": 454.0221,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        2000.1528
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.6892,
        3.2149
      ],
      "sigma": 3.5453,
      "is_singular": false
    },
    {
      "dataset": "oxide",
      "formula": "Thickness ~ 1 + (1 | Lot/Wafer)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 72,
      "objective": 454.0221,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        2000.1528
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.6892,
        3.2149
      ],
      "sigma": 3.5453,
      "is_singular": false
    },
    {
      "dataset": "pastes",
      "formula": "strength ~ 1 + (1 | sample) + (1 | batch)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 60,
      "objective": 246.9907,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        60.0533
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        3.5269,
        1.5635
      ],
      "sigma": 0.8234,
      "is_singular": false
    },
    {
      "dataset": "penicillin",
      "formula": "diameter ~ 1 + (1 | plate) + (1 | sample)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 144,
      "objective": 330.8606,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        22.9722
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.5397,
        3.5125
      ],
      "sigma": 0.5499,
      "is_singular": false
    },
    {
      "dataset": "rail",
      "formula": "travel ~ 1 + (1 | Rail)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 18,
      "objective": 122.177,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        66.5
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        6.1693
      ],
      "sigma": 4.0208,
      "is_singular": false
    },
    {
      "dataset": "sleepstudy",
      "formula": "Reaction ~ 1 + Days + (1 + Days | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 180,
      "objective": 1743.6283,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        251.4051,
        10.4673
      ],
      "coef_names": [
        "(Intercept)",
        "Days"
      ],
      "theta": [
        0.9667,
        0.0152,
        0.2309
      ],
      "sigma": 25.5918,
      "is_singular": false
    },
    {
      "dataset": "sleepstudy",
      "formula": "Reaction ~ 1 + Days + (1 + Days | Subject)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 180,
      "objective": 1751.9393,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        251.4051,
        10.4673
      ],
      "coef_names": [
        "(Intercept)",
        "Days"
      ],
      "theta": [
        0.9292,
        0.0182,
        0.2226
      ],
      "sigma": 25.5919,
      "is_singular": false
    },
    {
      "dataset": "station_season_duration",
      "formula": "effect ~ 1 + duration + (1 + duration | sites) + (1 + duration | season)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 54,
      "objective": 999.7489,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        4183.8958,
        3265.6409
      ],
      "coef_names": [
        "(Intercept)",
        "duration7d"
      ],
      "theta": [
        1.0324,
        0.4778,
        0,
        0.2452,
        0.2261,
        0
      ],
      "sigma": 2248.6159,
      "is_singular": true
    },
    {
      "dataset": "station_season_duration",
      "formula": "effect ~ 1 + duration * season * sites",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "error",
      "n_obs": 54,
      "objective_comparable": true
    },
    {
      "dataset": "station_season_duration",
      "formula": "effect ~ 1 + duration + (1 | sites) + (1 | season)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 54,
      "objective": 1003.105,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        4183.8958,
        3265.6409
      ],
      "coef_names": [
        "(Intercept)",
        "duration7d"
      ],
      "theta": [
        1.2211,
        0.3299
      ],
      "sigma": 2335.4299,
      "is_singular": false
    },
    {
      "dataset": "sleepstudy",
      "formula": "reaction ~ 1 + days + (1 + days | subj)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 180,
      "objective": 1751.9393444631976,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        251.40510484848525,
        10.46728595959606
      ],
      "coef_names": [
        "(Intercept)",
        "days"
      ],
      "theta": [
        0.9292254894909099,
        0.018165744800668356,
        0.22264541734402324
      ],
      "sigma": 25.591815568080015,
      "is_singular": false,
      "tolerances": {
        "objective": 0.001,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "sleepstudy",
      "formula": "reaction ~ 1 + days + (1 + days | subj)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 180,
      "objective": 1743.628271958491,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        251.4051048484852,
        10.467285959595813
      ],
      "coef_names": [
        "(Intercept)",
        "days"
      ],
      "theta": [
        0.9667328168874256,
        0.015169041703413504,
        0.23090958989185423
      ],
      "sigma": 25.591815947350575,
      "is_singular": false,
      "tolerances": {
        "objective": 0.001,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "penicillin",
      "formula": "diameter ~ 1 + (1 | plate) + (1 | sample)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 144,
      "objective": 332.1883486685007,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        22.97222222222176
      ],""",
    """
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        1.537593573444687,
        3.2197541569340533
      ],
      "sigma": 0.5499321918564227,
      "is_singular": false,
      "tolerances": {
        "objective": 0.001,
        "beta": 0.001,
        "theta": 0.001,
        "sigma": 0.001
      }
    },
    {
      "dataset": "pastes",
      "formula": "strength ~ 1 + (1 | batch / cask)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "ML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 60,
      "objective": 247.99446586242502,
      "objective_definition": "deviance",
      "objective_comparable": true,
      "beta": [
        60.05333333333204
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        3.526901817963633,
        1.329911712620909
      ],
      "sigma": 0.8234075628270361,
      "is_singular": false,
      "tolerances": {
        "objective": 0.001,
        "beta": 0.001,
        "theta": 0.005,
        "sigma": 0.001
      }
    },
    {
      "dataset": "pastes",
      "formula": "strength ~ 1 + (1 | batch / cask)",
      "family": "Gaussian",
      "link": "Identity",
      "estimator": "REML",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 60,
      "objective": 246.9907458534861,
      "objective_definition": "restricted_deviance",
      "objective_comparable": true,
      "beta": [
        60.05333333333329
      ],
      "coef_names": [
        "(Intercept)"
      ],
      "theta": [
        3.5269016913275544,
        1.5634606815008614
      ],
      "sigma": 0.8234075538293614,
      "is_singular": false,
      "tolerances": {
        "objective": 0.001,
        "beta": 0.001,
        "theta": 0.005,
        "sigma": 0.001
      }
    },
    {
      "dataset": "cbpp",
      "formula": "proportion ~ 1 + period + (1 | herd)",
      "family": "Binomial",
      "link": "Logit",
      "estimator": "joint_laplace",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 56,
      "objective": 184.05256374299438,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": true,
      "beta": [
        -1.3985321253936296,
        -0.9923327045517759,
        -1.1286720818886522,
        -1.5803138028664538
      ],
      "coef_names": [
        "(Intercept)",
        "period2",
        "period3",
        "period4"
      ],
      "theta": [
        0.642261427354827
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.0001,
        "beta": 0.001,
        "theta": 0.001
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=1"
    },
    {
      "dataset": "cbpp",
      "formula": "proportion ~ 1 + period + (1 | herd)",
      "family": "Binomial",
      "link": "Logit",
      "estimator": "fast_pirls",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 56,
      "objective": 184.10859094563688,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": false,
      "beta": [
        -1.3604717553032335,
        -0.9761774710044561,
        -1.1110768933722635,
        -1.5596805157095388
      ],
      "coef_names": [
        "(Intercept)",
        "period2",
        "period3",
        "period4"
      ],
      "theta": [
        0.6418150699438979
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.0001,
        "beta": 0.001,
        "theta": 0.001
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=0, documented fast divergence only"
    },
    {
      "dataset": "culcitalogreg",
      "formula": "predation ~ 1 + ttt + (1 | block)",
      "family": "Bernoulli",
      "link": "Logit",
      "estimator": "joint_laplace",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 80,
      "objective": 60.70589038642724,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": true,
      "beta": [
        5.09573662443926,
        -3.8422068002272187,
        -4.431011322169999,
        -5.59899518577491
      ],
      "coef_names": [
        "(Intercept)",
        "tttcrabs",
        "tttshrimp",
        "tttboth"
      ],
      "theta": [
        3.4366169986445048
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.0001,
        "beta": 0.001,
        "theta": 0.001
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=1"
    },
    {
      "dataset": "culcitalogreg",
      "formula": "predation ~ 1 + ttt + (1 | block)",
      "family": "Bernoulli",
      "link": "Logit",
      "estimator": "fast_pirls",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 80,
      "objective": 61.1239592877025,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": false,
      "beta": [
        4.111900523633656,
        -3.141113157491969,
        -3.707457813310895,
        -4.778101369337622
      ],
      "coef_names": [
        "(Intercept)",
        "tttcrabs",
        "tttshrimp",
        "tttboth"
      ],
      "theta": [
        3.3205124580145333
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.0001,
        "beta": 0.001,
        "theta": 0.001
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=0, documented fast divergence only"
    },
    {
      "dataset": "synthetic_poisson_offset",
      "formula": "count ~ 1 + x + (1 | group)",
      "family": "Poisson",
      "link": "Log",
      "estimator": "joint_laplace",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 24,
      "objective": 68.33363474264272,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": true,
      "beta": [
        0.3260365075368775,
        0.644843601539186
      ],
      "coef_names": [
        "(Intercept)",
        "x"
      ],
      "theta": [
        0.14306293690534047
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.0001,
        "beta": 0.001,
        "theta": 0.001
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=1"
    },
    {
      "dataset": "synthetic_poisson_offset",
      "formula": "count ~ 1 + x + (1 | group)",
      "family": "Poisson",
      "link": "Log",
      "estimator": "fast_pirls",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 24,
      "objective": 68.33713315663275,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": false,
      "beta": [
        0.33460071529454816,
        0.6448436012728309
      ],
      "coef_names": [
        "(Intercept)",
        "x"
      ],
      "theta": [
        0.14086050998139193
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.01,
        "beta": 0.001,
        "theta": 0.02
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=0, documented fast divergence only"
    },
    {
      "dataset": "synthetic_poisson_crossed",
      "formula": "count ~ 1 + x + (1 + x | site) + (1 | batch)",
      "family": "Poisson",
      "link": "Log",
      "estimator": "joint_laplace",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 300,
      "objective": 1293.8553080583465,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": true,
      "beta": [
        1.0927625985567762,
        0.3852252491442737
      ],
      "coef_names": [
        "(Intercept)",
        "x"
      ],
      "theta": [
        0.5112389399009235,
        0.19438493618692218,
        0.41163676927683074,
        0.3253080646444494
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.0001,
        "beta": 0.001,
        "theta": 0.001
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=1"
    },
    {
      "dataset": "synthetic_poisson_crossed",
      "formula": "count ~ 1 + x + (1 + x | site) + (1 | batch)",
      "family": "Poisson",
      "link": "Log",
      "estimator": "fast_pirls",
      "engine": "lme4",
      "status": "ok",
      "n_obs": 300,
      "objective": 1293.8596731436157,
      "objective_definition": "minus_two_loglikelihood_with_response_constants",
      "objective_comparable": false,
      "beta": [
        1.1047573802593815,
        0.3827297036115805
      ],
      "coef_names": [
        "(Intercept)",
        "x"
      ],
      "theta": [
        0.5112609978773305,
        0.19437555199312592,
        0.41162176654916954,
        0.3253836408852588
      ],
      "is_singular": false,
      "tolerances": {
        "objective": 0.0001,
        "beta": 0.001,
        "theta": 0.001
      },
      "provenance": "comparison/glmm-tranche/provenance.json",
      "response_and_offset_contract": "cbpp: proportion=incidence/size, trials=size; Poisson: offset=log(exposure); case weights=1",
      "reference_estimator": "lme4 nAGQ=0, documented fast divergence only"
    }
  ]
}
"""
  ).mkString
