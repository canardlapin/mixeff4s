# mixeff4s

Scala 3 port of [mixeff-rs](https://github.com/bbuchsbaum/mixeff-rs): linear and
generalized linear mixed-effects models with an explicit inference contract.
The numerical reference is MixedModels.jl; lme4 is the later release scorecard.

This is a re-expression, not a line-for-line translation. Fit is a value.
Unavailable inference is a refusal with a stable code. Do not invent p-values.

## Layout

JVM and Scala.js cross-project, many packages. Split artifacts when GLMM or the
compiler has a reason to exist independently.

```
mixeff4s.error      MixedModelError, LinAlgError, FitResult
mixeff4s.formula    AST, string parser, I() transforms, typed DSL
mixeff4s.data       ModelFrame — fitting substrate, not a dataframe library
mixeff4s.model      Family, Link
mixeff4s.design     FeTerm, FeMat, ReMat, parmap (Gale)
mixeff4s.linalg     WorkMat, MatrixBlock, blocked Cholesky
mixeff4s.optimizer  TrustBQ
mixeff4s.lmm        FitOptions, Lmm.compile, Lmm.fit, VarCorr, CoefTable
mixeff4s.glmm       GlmmOptions, Glmm.fit (labelled fast-PIRLS)
mixeff4s.stats      Lrt, Profile, Bootstrap (typed refusals when unavailable)
mixeff4s.compiler   Semantic IR and compiled-design JSON artifact (unstable)
mixeff4s.pathology  Design-time certificates, fit-time θ status, truth-spec corpus
```

Layer rules, enforced by `ArchitectureSuite`:

- `error` does not import `data`, `lmm`, `model`, or `glmm`
- `formula` does not import `lmm`, `model`, or `glmm`
- `data` does not import `formula`, `lmm`, `model`, or `glmm`
- `model` does not import `lmm`, `formula`, `data`, or `glmm`
- `linalg` does not import `lmm`, `formula`, `data`, `model`, `design`, `optimizer`, or `glmm`
- `optimizer` does not import `lmm`, `design`, `formula`, `data`, `model`, or `glmm`
- `lmm` does not import `glmm` or a future `compiler` or `stats` package
- `glmm` does not import a future `compiler` or `stats` package
- `stats` does not import a future `compiler` package
- `compiler` does not import `stats`
- `pathology` does not import `compiler`, `stats`, or `glmm`

## Build

```sh
sbt -Dmixeff4s.gale.build=/path/to/gale test
sbt -Dmixeff4s.gale.build=/path/to/gale mixeff4sJS/test
sbt scalafmtAll
```

Scala 3.7.4, sbt 1.12.14. Gale is pinned at `galeRevision` in `build.sbt`. A local checkout is admitted
only through `-Dmixeff4s.gale.build=/path/to/gale`. Do not add Cats Effect in
core.

Issue tracking is **mote**. Check `mote ready`, reserve paths, and publish
through the CLI. Do not hand-edit `.mote/ops`.

## Cursor Cloud

Cloud Agents use `.cursor/environment.json` and `.cursor/Dockerfile`. The
image has JDK 21, sbt, and Node. `install` warms Coursier caches with
`sbt -batch update Test/compile`. Gale is cloned from the pinned SHA in
`build.sbt`; do not pass `-Dmixeff4s.gale.build` unless a checkout is
present. Verify with `sbt test` (JVM and Scala.js). No secrets are required.

## Port phases

| Phase | Scope | Gate |
| --- | --- | --- |
| 0–1 | Language, frame, stub `Lmm.fit` | Parser + architecture tests |
| 2 | `FeTerm` / `ReMat` / `parmap` on Gale | Design shapes on sleepstudy |
| 3 | Blocked-Cholesky PLS + TrustBQ | sleepstudy β, θ, σ, objective |
| 4 | Public LMM API, VarCorr, Wald | Honest summaries |
| 5 | GLMM fast-PIRLS, labelled | Scorecard fast-PIRLS rows |
| 6 | LRT / profile / bootstrap | Nested LRT + refusal contracts |
| 7 | Compiler / pathology | JSON snapshots |

There is no Phase 8. Numerical evidence is a separate program under
`comparison/`: a scorecard, vendored frames, and frozen MixedModels.jl /
mixeff-rs / lme4 numbers. Default `sbt test` is frozen-first and does not
call R or Julia. Do not mark a row `release_blocking_parity` against lme4
until a frozen lme4 number exists and a mixeff4s fit is compared to it.
Fast-PIRLS is `documented_divergence`, never `lme4::glmer`.

Keep index-parallel PLS loops close to mixeff-rs until parity is green.

## Invariants

1. No fake p-values.
2. Certified fit or precise diagnostic.
3. lme4 formula semantics; Normal+Identity is an LMM, refused as a GLMM.
4. θ is Cholesky of relative covariance with an explicit parmap.
5. Profiled (RE)ML: the optimizer sees θ only.
6. GLMM `fast=true` is labelled fast-PIRLS, never sold as `lme4::glmer`.
7. Unsupported optimizer or covariance → error, not silent fallback.
8. Layer acyclicity.
