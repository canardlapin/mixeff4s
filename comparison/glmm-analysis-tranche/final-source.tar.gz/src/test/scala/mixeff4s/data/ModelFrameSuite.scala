package mixeff4s.data

import mixeff4s.error.MixedModelError
import mixeff4s.formula.Formula

class ModelFrameSuite extends munit.FunSuite:
  test("builds aligned numeric and factor columns"):
    val frame = ModelFrame
      .of(
        "y" -> ModelFrame.numeric(Vector(1.0, 2.0, 3.0)),
        "g" -> ModelFrame.factor(Vector("b", "a", "b"))
      )
      .getOrElse(fail("frame"))
    assertEquals(frame.nRows, 3)
    assertEquals(frame.factor("g").map(_.levels), Some(Vector("b", "a")))
    assertEquals(frame.factor("g").map(_.refs), Some(Vector(0, 1, 0)))

  test("encodes an explicit factor level order"):
    val factor = ModelFrame
      .factor(Vector("I", "VI", "I"), Vector("VI", "V", "I"))
      .getOrElse(fail("factor"))
    assertEquals(factor.levels, Vector("VI", "V", "I"))
    assertEquals(factor.refs, Vector(2, 0, 2))

  test("rejects a value outside the declared factor levels"):
    ModelFrame.factor(Vector("Z"), Vector("A", "B")) match
      case Left(MixedModelError.InvalidArgument(_)) => ()
      case other                                    => fail(s"expected invalid argument, got $other")

  test("rejects length mismatch"):
    ModelFrame.of(
      "y" -> ModelFrame.numeric(Vector(1.0, 2.0)),
      "x" -> ModelFrame.numeric(Vector(1.0))
    ) match
      case Left(MixedModelError.DimensionMismatch(_)) => ()
      case other                                      => fail(s"expected dimension mismatch, got $other")

  test("rejects non-finite numeric input at the frame boundary"):
    Vector(Double.NaN, Double.PositiveInfinity, Double.NegativeInfinity).foreach: bad =>
      ModelFrame.of("y" -> ModelFrame.numeric(Vector(1.0)), "x" -> ModelFrame.numeric(Vector(bad))) match
        case Left(MixedModelError.InvalidArgument(_)) => ()
        case other                                    => fail(s"expected invalid argument, got $other")

  test("rejects non-finite numeric columns added after frame construction"):
    val frame = ModelFrame.of("y" -> ModelFrame.numeric(Vector(1.0))).getOrElse(fail("frame"))
    frame.addNumeric("x", Vector(Double.NaN)) match
      case Left(MixedModelError.InvalidArgument(_)) => ()
      case other                                    => fail(s"expected invalid argument, got $other")

  test("validates raw factor references and values"):
    val invalid = Vector(
      Column.Factor(Vector("a", "b"), Vector(0), Vector("a", "b")),
      Column.Factor(Vector("a", "a"), Vector(0), Vector("a")),
      Column.Factor(Vector("a"), Vector(1), Vector("a")),
      Column.Factor(Vector("a", "b"), Vector(0), Vector("b"))
    )
    invalid.foreach: factor =>
      ModelFrame.of("y" -> ModelFrame.numeric(Vector(1.0)), "f" -> factor) match
        case Left(_: MixedModelError) => ()
        case other                    => fail(s"expected invalid raw factor, got $other")

  test("permits a legitimate empty aligned frame"):
    val frame = ModelFrame
      .of("y" -> ModelFrame.numeric(Vector.empty), "f" -> ModelFrame.factor(Vector.empty))
      .getOrElse(fail("empty frame"))
    assertEquals(frame.nRows, 0)

  test("materializes I() onto the frame"):
    val frame = ModelFrame
      .of(
        "y" -> ModelFrame.numeric(Vector(1.0, 4.0, 9.0)),
        "x" -> ModelFrame.numeric(Vector(1.0, 2.0, 3.0)),
        "g" -> ModelFrame.factor(Vector("a", "b", "c"))
      )
      .getOrElse(fail("frame"))
    val formula = Formula.parse("y ~ I(x^2) + (1 | g)").getOrElse(fail("parse"))
    val materialized = formula.materialize(frame).getOrElse(fail("materialize"))
    assertEquals(materialized.numeric("I(x^2)"), Some(Vector(1.0, 4.0, 9.0)))
