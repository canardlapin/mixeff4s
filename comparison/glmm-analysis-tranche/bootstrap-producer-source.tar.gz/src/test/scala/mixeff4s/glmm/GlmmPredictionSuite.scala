package mixeff4s.glmm

import mixeff4s.data.ModelFrame
import mixeff4s.fixtures.GlmmFrames
import mixeff4s.formula.Formula
import mixeff4s.lmm.{NewGroupPolicy, PredictionMode}
import mixeff4s.model.Family

class GlmmPredictionSuite extends munit.FunSuite:
  private def right[A](value: Either[?, A]): A = value.fold(error => fail(error.toString), identity)
  private lazy val fit =
    right(Glmm.fit(Formula.parse("predation ~ 1 + ttt + (1 | block)").toOption.get, GlmmFrames.culcitalogreg, Family.Bernoulli,
      options = GlmmOptions.fastLaplace.copy(maxEvaluations = 10000)))

  test("fitted link and response predictions preserve the fitted conditional snapshot"):
    val link = right(GlmmPrediction.fitted(fit, scale = GlmmPredictionScale.Link))
    val response = right(GlmmPrediction.fitted(fit))
    assertEquals(link.length, fit.n)
    link.zip(fit.conditionalEta).foreach((actual, expected) => assertEqualsDouble(actual, expected, 1e-8))
    response.zip(fit.conditionalMean).foreach((actual, expected) => assertEqualsDouble(actual, expected, 1e-8))

  test("population prediction removes modes and frozen encoding refuses unknown groups unless zero-effect is explicit"):
    val data = GlmmFrames.culcitalogreg
    val conditional = right(GlmmPrediction.predict(fit, data))
    val population = right(GlmmPrediction.predict(fit, data, PredictionMode.Population))
    assertEquals(conditional.length, population.length)
    assert(conditional.zip(population).exists((a, b) => math.abs(a - b) > 1e-12))
    val ttt = data.factor("ttt").get
    val unknown = right(ModelFrame.of("ttt" -> ModelFrame.factor(ttt.values, ttt.levels).toOption.get,
      "block" -> ModelFrame.factor(Vector.fill(data.nRows)("new-block"))))
    assertEquals(GlmmPrediction.predict(fit, unknown).left.toOption.get.code, "prediction_new_group")
    assert(GlmmPrediction.predict(fit, unknown, unknownGroups = NewGroupPolicy.ZeroEffect).isRight)

  test("raw and Pearson residuals are finite"):
    assert(right(GlmmPrediction.residuals(fit)).forall(_.isFinite))
    assert(right(GlmmPrediction.residuals(fit, GlmmResidualScale.Pearson)).forall(_.isFinite))
