# mixeff4s

[Repository](https://github.com/canardlapin/mixeff4s)

mixeff4s is a mixed-effects modeling library for Scala 3 that turns an lme4-style
formula and a column store into either a fit with recorded numerical termination or a typed refusal. Use
it when you want Bates/MixedModels PLS semantics without inventing a p-value.

> This is pre-release development software. APIs, semantics, and package
> boundaries may change. No stable support or binary-compatibility promise
> should be inferred unless the package explicitly states one.

**Status:** `prototype`. The formula language, model frame, family/link types,
Gale-backed design compilation, a blocked-Cholesky LMM kernel, and labelled
fast-PIRLS GLMMs are implemented. Joint Laplace/AGQ is refused.

## Quick start

The library is source-only. From this checkout:

```scala
import mixeff4s.prelude.*

val formula = Formula.parse("y ~ 1 + x + (1 | g)").toOption.get
formula.toString
// y ~ 1 + x + (1 | g)

val frame = ModelFrame.of(
  "y" -> numeric(Vector(1.0, 2.1, 3.0, 4.2, 5.1, 6.0)),
  "x" -> numeric(Vector(0.0, 1.0, 0.0, 1.0, 0.0, 1.0)),
  "g" -> factorCol(Vector("a", "a", "b", "b", "c", "c"))
).toOption.get

val fit = Lmm.fit(formula, frame, FitOptions.reml).toOption.get
(fit.beta, fit.sigma, fit.objective)
```

The same formula can be built without a string:

```scala
import mixeff4s.formula.dsl.dsl.*

val spec = response("y") ~ (intercept + col("x") + (intercept | factor("g")))
```

`cs(...)` and `ar1(...)` parse, then `Lmm.fit` refuses them. That is intentional:
a number means what it says, otherwise you get a matchable reason code.

## What it covers

- Parse the supported lme4 subset: intercepts, `:` / `*` / `/`, `(re | g)`,
  `(re || g)`, nested and crossed grouping, `us` / `diag` / `cs` / `ar1`
- Lower a typed DSL into the same formula IR
- Evaluate the stateless `I(...)` / `log` / `sqrt` transform subset onto a frame
- Name GLMM families and links, including the rule that Normal+Identity is an LMM
- Compile a formula and frame into `FeTerm`, `ReMat`s, and the live θ `parmap`
- Fit profiled (RE)ML with blocked Cholesky + TrustBQ, including crossed intercepts
- Report VarCorr, Wald SEs, and z-statistics; p-values stay a typed refusal
- Fit labelled fast-PIRLS GLMMs (`Glmm.fit`); Normal+Identity is refused as a GLMM
- Compare nested LMMs with `Lrt.compare`; profile intervals and bootstrap stay typed refusals
- Emit a versioned compiled-design JSON artifact with a design-time pathology certificate; raw θ assessment reports geometry, while assessment of an `LmmFit` also checks its optimizer evidence

## Fit and boundaries

Good fit for describing mixed models, fitting the current LMM kernel
(sleepstudy, penicillin, pastes), and labelled fast-PIRLS Bernoulli GLMMs
(contra). Structured RE covariance and joint Laplace/AGQ are not implemented.

Out of scope for this slice, and for the Rust 1.0 line we are porting:

- Multivariate responses
- Residual AR/spatial correlation
- Structured RE covariance as a fitted family
- GLMM profile likelihood
- A published Maven coordinate

Design compilation depends on [Gale](https://github.com/canardlapin/gale)
through an exact source pin in `build.sbt`. A local checkout is admitted only
via `-Dmixeff4s.gale.build=/path/to/gale`.

## Maturity and verification

| Question | Answer |
| --- | --- |
| What does it do? | Mixed-model language, frame, design compilation, profiled LMM fitting, labelled fast-PIRLS GLMMs, nested LRT, compiled-design artifacts, and honest summaries |
| Smallest useful example? | Parse `y ~ 1 + x + (1 \| g)` and inspect the IR |
| Maturity / publication? | `prototype`, source-only, unpublished at [canardlapin/mixeff4s](https://github.com/canardlapin/mixeff4s) |
| How to verify? | `sbt -Dmixeff4s.gale.build=/path/to/gale test` (JVM and Scala.js). Default tests read frozen numbers; they do not call R or Julia. |

Platform: JVM and Scala.js (Node). Scala 3.7.4, sbt 1.12.14. The numeric kernel
is Gale, which already cross-builds; mixeff4s follows it. The source-tree
architecture walk is JVM-only.

Fits retain the TrustBQ result as `fit.optimizer`; GLMM fits also retain the
final inner-loop criterion as `fit.pirls`. Exhausted optimizer budgets and
unfinished PIRLS return typed errors (`optimizer_budget_exhausted`,
`pirls_not_converged`, or `pirls_step_failed`). `FitOptions.maxEvaluations`
limits the main LMM search, excluding the advisory diagonal warm start;
`GlmmOptions` exposes `maxEvaluations` and `pirlsMaxIterations`.

These are numerical stopping criteria, not gradient/Hessian or global-optimum
certificates. `Compiler.assess(artifact, fit)` uses the LMM's recorded evidence.
`Compiler.assess(artifact, theta)` leaves `fitStatus` as `NotAssessed`, even
for an interior θ. Compiled-design schema version 2 reports `theta_geometry`
separately from `fit_status`. The existing `converged_*` codes on fit-backed
assessments mean the optimizer met its numerical stopping criterion.
Fast-PIRLS retains its objective-change convergence rule after finite step
halving; `fit.pirls.halvingLimitHits` records exhausted halving bounds. It does
not use the conditional-score criterion of the joint-Laplace estimator.

Fixed-effect outputs use retained design-column order. For an LMM, `beta`,
`feNames`, `stderror`, coefficient-table rows, and both axes of `vcov` describe
the same retained columns; covariance is not padded with aliased rows.
Both LMM and GLMM fits expose `fixedEffects: FixedEffectLayout`, containing
`requestedNames`, `retainedIndices`, `retainedNames`, `droppedIndices`, and
`droppedNames`. Indices are zero-based positions in the expanded design, not
formula-term indices. Dropped coefficients are not separately identified by
the selected reduced model. Retained estimates and covariance describe that
selected basis; they do not establish separate estimability of coefficients
in the original redundant parameterization.

This changes the pre-release fit constructors: pass `fixedEffects` instead of
`feNames`; reading `fit.feNames` remains supported. Direct construction or
`copy` with inconsistent layout/covariance/table dimensions throws
`IllegalArgumentException`. The fitting methods continue returning `FitResult`
for recoverable model errors.

Likelihood comparisons retain immutable, row-aligned design evidence in
`LmmFit.designEvidence`. `Lrt.statistic(smaller, larger)` returns the likelihood
ratio and nominal parameter-count difference after checking response, criterion,
actual retained fixed columns, grouping partitions, random basis columns, and
covariance constraints. Intercepts are ordinary basis columns in this check.
The check proves nesting by exact column inclusion; it conservatively refuses
other equivalent parameterizations. REML requires the same retained fixed basis
up to permutation, since rescaling can change its likelihood normalization.

`Lrt.compare` supplies an **asymptotic chi-square approximation** only for nested
fixed-effect ML comparisons with unchanged random covariance design. It returns
`lrt_reference_unavailable` for covariance changes and for either fit having a
Cholesky diagonal at or below `1e-8`. This boundary screen is conservative and
is not a condition-number or asymptotic-adequacy certificate. Covariance-changing
comparisons can still use `Lrt.statistic`; no p-value is implied. For example,
random intercept → random intercept plus slope has a verified statistic, but
its reference law is not implemented. Other unsupported or invalid comparisons
return `lrt_unavailable`. Manually constructed fits without matching design and
numerical termination evidence are refused. Profile and bootstrap calibration
remain unavailable.

Numerical evidence lives in `comparison/`. MixedModels.jl is the current
reference for the rows we already fit. lme4 is the later scorecard: frozen
lme4 numbers may be checked in without being a mixeff4s claim. Fast-PIRLS
rows stay labelled and are never sold as `lme4::glmer`. This evidence
program is not a new port phase.

This is a Scala 3 re-expression of
[mixeff-rs](https://github.com/bbuchsbaum/mixeff-rs), itself an independent
implementation of MixedModels.jl's PLS/PIRLS formulation. It is not a
line-for-line Rust translation.

## Documentation

- [AGENTS.md](AGENTS.md) — package layout, layering, and port phases
- mixeff-rs guide — [what is supported](https://github.com/bbuchsbaum/mixeff-rs/blob/main/docs/guide/05_what_is_supported.md)

## License

Apache-2.0. The Rust reference crate is MIT.
