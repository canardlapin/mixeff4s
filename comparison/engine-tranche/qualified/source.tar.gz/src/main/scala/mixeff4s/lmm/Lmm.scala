package mixeff4s.lmm

import mixeff4s.data.ModelFrame
import mixeff4s.design.{CompiledDesign, Design, FixedEffectLayout}
import mixeff4s.error.{FitResult, MixedModelError}
import mixeff4s.formula.Formula
import mixeff4s.optimizer.TrustBqResult

enum Criterion:
  case ML, REML

enum LmmOptimizer:
  case DerivativeFree, AnalyticGradient

/** maxEvaluations bounds the main optimizer, excluding the advisory diagonal start. */
final case class FitOptions(
    criterion: Criterion,
    maxEvaluations: Int = 1000,
    optimizer: LmmOptimizer = LmmOptimizer.DerivativeFree,
    gradientOptions: ProfiledGradientOptions = ProfiledGradientOptions()
)

object FitOptions:
  def ml: FitOptions = FitOptions(Criterion.ML)
  def reml: FitOptions = FitOptions(Criterion.REML)

/** Profiled LMM fit with recorded numerical termination; stationarity is not certified. */
final case class LmmFit(
    formula: Formula,
    options: FitOptions,
    n: Int,
    y: Vector[Double],
    theta: Vector[Double],
    beta: Vector[Double],
    sigma: Double,
    objective: Double,
    fixedEffects: FixedEffectLayout,
    vcov: Vector[Vector[Double]],
    varcorr: VarCorr,
    logdetRe: Double,
    optimizer: TrustBqResult,
    parmap: Vector[(Int, Int, Int)],
    designEvidence: Option[LmmDesignEvidence] = None
):
  require(beta.length == fixedEffects.rank, "beta length must match the retained fixed-effect layout")
  require(
    vcov.length == beta.length && vcov.forall(_.length == beta.length),
    "vcov must be square in retained fixed-effect order"
  )

  def feNames: Vector[String] = fixedEffects.retainedNames

  def dof: Int = beta.length + theta.length + 1

  def loglikelihood: Double = -0.5 * objective

  def stderror: Vector[Double] =
    vcov.zipWithIndex.map((row, i) => math.sqrt(row(i)))

  def coefTable: CoefTable =
    CoefTable.wald(feNames, beta, stderror)

/** Linear mixed-model front door: compile a formula against a frame, then fit. */
object Lmm:
  def compile(formula: Formula, frame: ModelFrame): FitResult[CompiledDesign] =
    Design.compile(formula, frame)

  def compile(source: String, frame: ModelFrame): FitResult[CompiledDesign] =
    Formula.parse(source) match
      case Left(err)      => Left(MixedModelError.Formula(err))
      case Right(formula) => compile(formula, frame)

  def fit(
      formula: Formula,
      frame: ModelFrame,
      options: FitOptions = FitOptions.reml
  ): FitResult[LmmFit] =
    compile(formula, frame).flatMap(design => fit(design, options))

  /** Fit an already compiled design without parsing, encoding or rank analysis again. */
  def fit(design: CompiledDesign, options: FitOptions): FitResult[LmmFit] =
    Pls
      .fit(
        design,
        options.criterion == Criterion.REML,
        options.maxEvaluations,
        options.optimizer,
        options.gradientOptions
      )
      .map(result => snapshot(result, options))

  def prepare(formula: Formula, frame: ModelFrame): FitResult[CompiledLmm] =
    compile(formula, frame).map(new CompiledLmm(_))

  def prepare(source: String, frame: ModelFrame): FitResult[CompiledLmm] =
    compile(source, frame).map(new CompiledLmm(_))

  private[lmm] def snapshot(result: PlsFit, options: FitOptions): LmmFit =
    val workspace = result.workspace
    val design = workspace.design
    val response = workspace.response
    LmmFit(
      design.formula,
      options,
      design.n,
      response,
      workspace.theta,
      workspace.beta,
      workspace.sigma,
      workspace.objective,
      design.fe.fixedEffects,
      workspace.vcov,
      workspace.varcorr,
      workspace.logdetRe,
      result.optimizer,
      design.parmap,
      Some(LmmDesignEvidence.capture(design, options.criterion, workspace.theta, workspace.objective, response))
    )

  def fit(
      source: String,
      frame: ModelFrame,
      options: FitOptions
  ): FitResult[LmmFit] =
    Formula.parse(source) match
      case Left(err)      => Left(MixedModelError.Formula(err))
      case Right(formula) => fit(formula, frame, options)
